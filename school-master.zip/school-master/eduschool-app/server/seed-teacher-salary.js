const { PrismaClient, AdjType, ManualEntryType } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  try {
    console.log('🌱 Seeding teacher salary data...\n');

    // 1. Find the teacher
    let teacher = await prisma.user.findUnique({
      where: { email: 'testteacher@example.com' },
      include: { school: true, staffProfile: true }
    });

    // Fallback to alternative email
    if (!teacher) {
      teacher = await prisma.user.findUnique({
        where: { email: 'teacher@example.com' },
        include: { school: true, staffProfile: true }
      });
    }

    // Fallback: get first TEACHER user
    if (!teacher) {
      teacher = await prisma.user.findFirst({
        where: { role: 'TEACHER' },
        include: { school: true, staffProfile: true }
      });
    }

    if (!teacher) {
      console.log('ERROR: No teacher found. Run create-teacher.js first.');
      process.exit(1);
    }

    if (!teacher.school) {
      console.log('ERROR: Teacher has no school assigned.');
      process.exit(1);
    }

    const schoolId = teacher.schoolId;
    console.log(`✓ Found teacher: ${teacher.firstName} ${teacher.lastName}`);
    console.log(`  School: ${teacher.school.name}\n`);

    // 2. Create or update StaffProfile
    let staffProfile = teacher.staffProfile;
    if (!staffProfile) {
      staffProfile = await prisma.staffProfile.create({
        data: {
          userId: teacher.id,
          salaryRate: 500.00, // USD per lesson
          position: 'English Teacher',
          hireDate: new Date('2025-01-15')
        }
      });
      console.log('✓ Created StaffProfile');
      console.log(`  Salary rate: $${staffProfile.salaryRate}/lesson\n`);
    } else {
      console.log(`✓ StaffProfile exists`);
      console.log(`  Salary rate: $${staffProfile.salaryRate}/lesson\n`);
    }

    // 3. Get or create Cabinet (classroom)
    let cabinet = await prisma.cabinet.findFirst({
      where: { schoolId }
    });

    if (!cabinet) {
      cabinet = await prisma.cabinet.create({
        data: {
          name: 'Main Hall',
          capacity: 20,
          schoolId
        }
      });
      console.log('✓ Created Cabinet: Main Hall\n');
    }

    // 4. Get or create StudentGroup
    let group = await prisma.studentGroup.findFirst({
      where: { schoolId }
    });

    if (!group) {
      group = await prisma.studentGroup.create({
        data: {
          schoolId,
          name: 'Morning Grammar — Group 1',
          level: 'Intermediate',
          maxStudents: 15
        }
      });
      console.log(`✓ Created StudentGroup: ${group.name}\n`);
    }

    // 5. Create LessonBlock (recurring class schedule)
    let block = await prisma.lessonBlock.findFirst({
      where: {
        schoolId,
        teacherId: staffProfile.id
      }
    });

    if (!block) {
      block = await prisma.lessonBlock.create({
        data: {
          schoolId,
          studentGroupId: group.id,
          cabinetId: cabinet.id,
          teacherId: staffProfile.id,
          startTime: '09:00',
          endTime: '10:20',
          days: 'Пн,Ср,Пт',
          level: 'Intermediate',
          maxStudents: 15,
          type: 'GRAMMAR',
          status: 'UPCOMING',
          startDate: new Date('2026-03-01')
        }
      });
      console.log(`✓ Created LessonBlock`);
      console.log(`  Days: Mon, Wed, Fri | 09:00–10:20\n`);
    }

    // 6. Create LessonSessions for the past 3 months
    const now = new Date();
    const months = [-3, -2, -1, 0]; // 3 months back to current

    console.log('📅 Creating lesson sessions...\n');

    let totalSessionsCreated = 0;

    for (const monthOffset of months) {
      const targetMonth = new Date(now.getFullYear(), now.getMonth() + monthOffset, 1);
      const year = targetMonth.getFullYear();
      const month = targetMonth.getMonth() + 1;
      const monthStr = `${year}-${String(month).padStart(2, '0')}`;

      // Create sessions for Mon, Wed, Fri of each week
      const firstDay = new Date(year, month - 1, 1);
      const lastDay = new Date(year, month, 0);

      let sessionsInMonth = 0;
      for (let d = new Date(firstDay); d <= lastDay; d.setDate(d.getDate() + 1)) {
        const dayOfWeek = d.getDay(); // 0=Sun, 1=Mon, 5=Fri
        const isScheduledDay = dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5; // Mon, Wed, Fri

        if (isScheduledDay) {
          // Only create sessions for past dates or very recent ones
          const isPast = d < now;

          if (isPast || (d.getMonth() === now.getMonth() && d.getDate() <= now.getDate())) {
            const sessionDate = new Date(d);
            sessionDate.setHours(9, 0, 0, 0);

            // Check if session already exists
            const existing = await prisma.lessonSession.findFirst({
              where: {
                lessonBlockId: block.id,
                date: {
                  gte: new Date(sessionDate.getTime() - 60000),
                  lte: new Date(sessionDate.getTime() + 60000)
                }
              }
            });

            if (!existing) {
              await prisma.lessonSession.create({
                data: {
                  schoolId,
                  lessonBlockId: block.id,
                  teacherId: staffProfile.id,
                  date: sessionDate,
                  status: isPast ? 'COMPLETED' : 'UPCOMING'
                }
              });
              sessionsInMonth++;
              totalSessionsCreated++;
            }
          }
        }
      }

      if (sessionsInMonth > 0) {
        console.log(`  ${monthStr}: ${sessionsInMonth} sessions created`);
      }
    }

    console.log(`\n✓ Total sessions created: ${totalSessionsCreated}\n`);

    // 7. Create SalaryAdjustments (bonuses, fines, advances)
    console.log('💰 Adding salary adjustments...\n');

    const adjustments = [
      {
        month: new Date(now.getFullYear(), now.getMonth() - 2, 1).toISOString().slice(0, 7),
        type: AdjType.BONUS,
        amount: 100.00,
        reason: 'Perfect attendance bonus'
      },
      {
        month: new Date(now.getFullYear(), now.getMonth() - 2, 1).toISOString().slice(0, 7),
        type: AdjType.FINE,
        amount: 50.00,
        reason: 'Late for 1 class'
      },
      {
        month: new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().slice(0, 7),
        type: AdjType.ADVANCE,
        amount: 500.00,
        reason: 'Advance payment for travel'
      },
      {
        month: new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().slice(0, 7),
        type: AdjType.BONUS,
        amount: 200.00,
        reason: 'Student satisfaction bonus'
      },
      {
        month: new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 7),
        type: AdjType.BONUS,
        amount: 150.00,
        reason: 'Excellent class ratings'
      }
    ];

    for (const adj of adjustments) {
      // Check if exists
      const existing = await prisma.salaryAdjustment.findFirst({
        where: {
          staffProfileId: staffProfile.id,
          month: adj.month,
          reason: adj.reason
        }
      });

      if (!existing) {
        await prisma.salaryAdjustment.create({
          data: {
            schoolId,
            staffProfileId: staffProfile.id,
            type: adj.type,
            amount: adj.amount,
            reason: adj.reason,
            month: adj.month,
            date: new Date(adj.month + '-15')
          }
        });
        console.log(`  ${adj.month} | ${adj.type} | $${adj.amount} | ${adj.reason}`);
      }
    }

    console.log();

    // 7b. Create ManualLessonEntries (admin-added manual adjustments)
    console.log('📝 Adding manual lesson entries...\n');

    const manualEntries = [
      {
        month: new Date(now.getFullYear(), now.getMonth() - 2, 1).toISOString().slice(0, 7),
        type: ManualEntryType.ADD,
        label: 'Замена 15 марта (группа B)',
        count: 2
      },
      {
        month: new Date(now.getFullYear(), now.getMonth() - 2, 1).toISOString().slice(0, 7),
        type: ManualEntryType.REMOVE,
        label: 'Прогул (болезнь)',
        count: 1
      },
      {
        month: new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().slice(0, 7),
        type: ManualEntryType.ADD,
        label: 'Дополнительный семинар',
        count: 1
      },
      {
        month: new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 7),
        type: ManualEntryType.ADD,
        label: 'Замена выходного дня',
        count: 1
      }
    ];

    for (const entry of manualEntries) {
      // Check if exists
      const existing = await prisma.manualLessonEntry.findFirst({
        where: {
          staffProfileId: staffProfile.id,
          month: entry.month,
          label: entry.label
        }
      });

      if (!existing) {
        await prisma.manualLessonEntry.create({
          data: {
            schoolId,
            staffProfileId: staffProfile.id,
            type: entry.type,
            label: entry.label,
            count: entry.count,
            month: entry.month
          }
        });
        console.log(`  ${entry.month} | ${entry.type === 'ADD' ? '+' : '−'}${entry.count} | ${entry.label}`);
      }
    }

    console.log();

    // 8. Create TeacherPayment records (payment history)
    console.log('📋 Creating payment history...\n');

    const paymentMonths = [
      new Date(now.getFullYear(), now.getMonth() - 2, 1).toISOString().slice(0, 7),
      new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().slice(0, 7)
    ];

    for (const period of paymentMonths) {
      // Check if payment exists
      const existing = await prisma.teacherPayment.findFirst({
        where: {
          staffProfileId: staffProfile.id,
          period
        }
      });

      if (!existing) {
        // Count sessions in this period
        const [year, month] = period.split('-').map(Number);
        const startDate = new Date(year, month - 1, 1);
        const endDate = new Date(year, month, 0, 23, 59, 59);

        const sessionCount = await prisma.lessonSession.count({
          where: {
            lessonBlockId: block.id,
            status: 'COMPLETED',
            date: {
              gte: startDate,
              lte: endDate
            }
          }
        });

        // Calculate payment
        const grossAmount = sessionCount * Number(staffProfile.salaryRate);
        const monthAdj = adjustments.filter(a => a.month === period);
        const bonuses = monthAdj.filter(a => a.type === AdjType.BONUS).reduce((s, a) => s + a.amount, 0);
        const fines = monthAdj.filter(a => a.type === AdjType.FINE).reduce((s, a) => s + a.amount, 0);
        const advances = monthAdj.filter(a => a.type === AdjType.ADVANCE).reduce((s, a) => s + a.amount, 0);
        const netAmount = grossAmount + bonuses - fines - advances;

        await prisma.teacherPayment.create({
          data: {
            schoolId,
            staffProfileId: staffProfile.id,
            period,
            lessonsCount: sessionCount,
            rateSnapshot: staffProfile.salaryRate,
            amount: netAmount,
            note: `Payment for ${period}`,
            paidAt: new Date(period + '-30')
          }
        });

        console.log(`  ${period} | ${sessionCount} lessons | $${Number(staffProfile.salaryRate)}/lesson = $${grossAmount}`);
        if (bonuses) console.log(`    + Bonuses: $${bonuses}`);
        if (fines) console.log(`    - Fines: $${fines}`);
        if (advances) console.log(`    - Advance: $${advances}`);
        console.log(`    = Net: $${netAmount}\n`);
      }
    }

    console.log('✅ Seed complete!\n');
    console.log(`📊 Summary:`);
    console.log(`  • Teacher: ${teacher.firstName} ${teacher.lastName}`);
    console.log(`  • School: ${teacher.school.name}`);
    console.log(`  • Salary rate: $${staffProfile.salaryRate}/lesson`);
    console.log(`  • Lesson sessions: ${totalSessionsCreated}`);
    console.log(`  • Salary adjustments: ${adjustments.length}`);
    console.log(`  • Manual lesson entries: ${manualEntries.length}`);
    console.log(`  • Payment records: ${paymentMonths.length}`);
    console.log(`\n🔗 Login at: http://localhost:5173/${teacher.school.slug}/login`);
    console.log(`  Email: teacher@example.com`);
    console.log(`  Password: teacher123\n`);
    console.log(`📱 In teacher's "Зарплата" tab, you'll see:`);
    console.log(`  ✓ Rate: $${staffProfile.salaryRate}/lesson`);
    console.log(`  ✓ Auto-calculated lessons from schedule`);
    console.log(`  ✓ Manual adjustments (добавлено админом)`);
    console.log(`  ✓ Штрафы, авансы, бонусы (amounts only, no admin names)`);
    console.log(`  ✓ Net salary total\n`);

  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();
