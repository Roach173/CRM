const { PrismaClient } = require('@prisma/client');
const p = new PrismaClient();
p.studentGroup.findMany({ 
  where: { schoolId: 1 }, 
  select: { id: true, name: true, deletedAt: true, status: true } 
}).then(r => console.log(JSON.stringify(r, null, 2))).catch(console.error).finally(() => p.$disconnect());
