const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('🔧 Fixing startTime/endTime split...\n');

  // Find blocks where endTime is empty
  const blocksToFix = await prisma.lessonBlock.findMany({
    where: { endTime: '' },
    select: { id: true, startTime: true, endTime: true, level: true }
  });

  console.log(`Found ${blocksToFix.length} blocks with empty endTime:\n`);

  let fixed = 0;
  for (const block of blocksToFix) {
    const st = block.startTime.trim();
    const en = block.endTime.trim();

    // Check if startTime contains both start and end times (with – or -)
    const match = st.match(/^(.+?)[–-](.+)$/);

    if (match) {
      const cleanStart = match[1].trim();
      const cleanEnd = match[2].trim().replace(/[–-]+$/, ''); // Remove trailing dashes

      // Check if this looks like times or like something else
      const isTime = /^\d{1,2}:\d{2}/.test(cleanStart);

      if (isTime && cleanStart !== cleanEnd) {
        await prisma.lessonBlock.update({
          where: { id: block.id },
          data: {
            startTime: cleanStart,
            endTime: cleanEnd
          }
        });
        console.log(`  ✓ ID ${block.id}: "${st}" → startTime="${cleanStart}" + endTime="${cleanEnd}"`);
        fixed++;
      } else {
        console.log(`  ⊘ ID ${block.id}: "${st}" (not a time range)`);
      }
    } else {
      console.log(`  ⊘ ID ${block.id}: "${st}" (no separator found)`);
    }
  }

  console.log(`\n✅ Fixed ${fixed} blocks!`);

  // Verify
  const remaining = await prisma.lessonBlock.findMany({
    where: { endTime: '' }
  });

  console.log(`Remaining blocks with empty endTime: ${remaining.length}`);

  process.exit(0);
}

main().catch(e => {
  console.error('❌ Error:', e.message);
  process.exit(1);
});
