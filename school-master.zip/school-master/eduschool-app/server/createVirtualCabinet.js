const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const schools = await prisma.school.findMany();
  for (const school of schools) {
    const exists = await prisma.cabinet.findFirst({
      where: { schoolId: school.id, name: 'Online / Zoom' }
    });
    if (!exists) {
      await prisma.cabinet.create({
        data: { schoolId: school.id, name: 'Online / Zoom', capacity: 999 }
      });
      console.log('Created for school ' + school.id);
    } else {
      console.log('Already exists for school ' + school.id);
    }
  }
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
