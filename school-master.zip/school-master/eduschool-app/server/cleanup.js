const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function cleanup() {
  try {
    const lessonBlockUpdated = await prisma.$executeRaw`
      UPDATE "LessonBlock"
      SET "teacherId" = NULL
      WHERE "teacherId" NOT IN (SELECT id FROM "StaffProfile" WHERE "deletedAt" IS NULL)
    `;
    console.log(`Updated ${lessonBlockUpdated} LessonBlock records`);

    const lessonSessionUpdated = await prisma.$executeRaw`
      UPDATE "LessonSession"
      SET "teacherId" = NULL
      WHERE "teacherId" NOT IN (SELECT id FROM "StaffProfile" WHERE "deletedAt" IS NULL)
    `;
    console.log(`Updated ${lessonSessionUpdated} LessonSession records`);

    console.log('Cleanup completed!');
  } catch (err) {
    console.error('Error:', err);
  } finally {
    await prisma.$disconnect();
  }
}

cleanup();
