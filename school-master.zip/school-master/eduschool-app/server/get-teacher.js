const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  try {
    const teachers = await prisma.user.findMany({
      where: { role: 'TEACHER' },
      include: { school: true },
      take: 5
    });

    if (teachers.length === 0) {
      console.log('No teachers found. Creating one...\n');

      const schools = await prisma.school.findMany({ take: 1 });
      if (schools.length === 0) {
        console.log('ERROR: No schools in database. Register a school first at http://localhost:5173/register-school');
        process.exit(1);
      }

      const school = schools[0];
      console.log(`Using school: ${school.name} (${school.slug})`);

      // Create a test teacher
      const teacher = await prisma.user.create({
        data: {
          email: 'teacher@example.com',
          password: '$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86.QzQVJ9pu', // "password"
          firstName: 'Test',
          lastName: 'Teacher',
          role: 'TEACHER',
          schoolId: school.id,
          isVerified: true
        }
      });

      console.log('\n✓ Teacher created:');
      console.log(`  Email: ${teacher.email}`);
      console.log(`  Password: password`);
      console.log(`  School: ${school.slug}`);
    } else {
      console.log('Existing teachers:\n');
      teachers.forEach(t => {
        console.log(`  Email: ${t.email}`);
        console.log(`  Name: ${t.firstName} ${t.lastName}`);
        console.log(`  School: ${t.school.slug}`);
        console.log(`  (Note: Password unknown - use "Reset Password" on login page)\n`);
      });
    }
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

main();
