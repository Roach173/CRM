const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function check() {
  try {
    const teachers = await prisma.$queryRaw`
      SELECT u.id, u."firstName", u."lastName", s.id as "staffProfileId"
      FROM "User" u
      LEFT JOIN "StaffProfile" s ON u.id = s."userId"
      WHERE u.id IN (2241, 2242, 2243, 2244, 2245, 2246, 2247, 2248, 2249, 2250)
      ORDER BY u.id
    `;
    console.log('Teachers with StaffProfile check:');
    console.log(JSON.stringify(teachers, null, 2));

    const missingStaffProfile = teachers.filter(t => t.staffProfileId === null);
    console.log(`\nMissing StaffProfile: ${missingStaffProfile.length}`);
    if (missingStaffProfile.length > 0) {
      console.log(JSON.stringify(missingStaffProfile, null, 2));
    }
  } catch (err) {
    console.error('Error:', err);
  } finally {
    await prisma.$disconnect();
  }
}

check();
