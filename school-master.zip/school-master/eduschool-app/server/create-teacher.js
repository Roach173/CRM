const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const prisma = new PrismaClient();

async function main() {
  try {
    const school = await prisma.school.findFirst();
    if (!school) {
      console.log('ERROR: No schools found');
      process.exit(1);
    }

    const hashedPassword = await bcrypt.hash('teacher123', 10);

    const teacher = await prisma.user.create({
      data: {
        email: 'testteacher@example.com',
        password: hashedPassword,
        firstName: 'Test',
        lastName: 'Teacher',
        role: 'TEACHER',
        school: { connect: { id: school.id } }
      }
    });

    console.log('✓ Teacher account created:\n');
    console.log(`  Email: ${teacher.email}`);
    console.log(`  Password: teacher123`);
    console.log(`  School: ${school.slug}`);
    console.log(`\n  Login at: http://localhost:5173/${school.slug}/login`);
  } catch (error) {
    if (error.code === 'P2002') {
      console.log('Teacher already exists. Using existing account:\n');
      console.log('  Email: testteacher@example.com');
      console.log('  Password: teacher123');
    } else {
      console.error('Error:', error.message);
    }
  } finally {
    await prisma.$disconnect();
  }
}

main();
