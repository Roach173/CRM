const { PrismaClient } = require('@prisma/client');
const p = new PrismaClient();
p.lessonSession.findMany({ 
  where: { schoolId: 1 },
  orderBy: { date: 'asc' },
  select: { id: true, date: true, lessonBlockId: true, status: true }
}).then(r => {
  console.log('Total sessions:', r.length);
  if (r.length > 0) {
    console.log('First:', r[0].date);
    console.log('Last:', r[r.length-1].date);
    const blockCounts = {};
    r.forEach(s => { blockCounts[s.lessonBlockId] = (blockCounts[s.lessonBlockId] || 0) + 1; });
    console.log('Sessions per block:', JSON.stringify(blockCounts, null, 2));
  }
}).catch(console.error).finally(() => p.$disconnect());
