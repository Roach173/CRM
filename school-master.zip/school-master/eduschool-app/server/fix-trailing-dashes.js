const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function main() {
  console.log('🔧 Fixing trailing dashes in LessonBlock fields...\n');

  // Get blocks with dashes before fixing
  const blocksWithDashes = await prisma.lessonBlock.findMany({
    where: {
      OR: [
        { startTime: { endsWith: '-' } },
        { endTime: { endsWith: '-' } },
        { level: { endsWith: '-' } }
      ]
    },
    select: { id: true, startTime: true, endTime: true, level: true }
  });

  console.log(`Found ${blocksWithDashes.length} blocks with trailing dashes:\n`);
  blocksWithDashes.forEach(b => {
    console.log(`  ID ${b.id}: "${b.startTime}" | "${b.endTime}" | "${b.level}"`);
  });

  if (blocksWithDashes.length === 0) {
    console.log('✅ No dashes found, database is clean!');
    process.exit(0);
  }

  // Fix the dashes
  console.log(`\n⏳ Removing trailing dashes...\n`);

  for (const block of blocksWithDashes) {
    const cleanStart = block.startTime.replace(/-+$/, '');
    const cleanEnd = block.endTime.replace(/-+$/, '');
    const cleanLevel = block.level.replace(/-+$/, '');

    await prisma.lessonBlock.update({
      where: { id: block.id },
      data: {
        startTime: cleanStart,
        endTime: cleanEnd,
        level: cleanLevel
      }
    });

    console.log(`  ✓ ID ${block.id}: "${cleanStart}" | "${cleanEnd}" | "${cleanLevel}"`);
  }

  // Verify
  const remaining = await prisma.lessonBlock.findMany({
    where: {
      OR: [
        { startTime: { endsWith: '-' } },
        { endTime: { endsWith: '-' } },
        { level: { endsWith: '-' } }
      ]
    }
  });

  console.log(`\n✅ Fixed ${blocksWithDashes.length} blocks!`);
  console.log(`Remaining blocks with dashes: ${remaining.length}`);

  process.exit(0);
}

main().catch(e => {
  console.error('❌ Error:', e.message);
  process.exit(1);
});
