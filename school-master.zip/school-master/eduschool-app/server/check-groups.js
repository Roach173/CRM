const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const groups = await prisma.studentGroup.findMany({
    where: {
      OR: [{ level: { endsWith: '-' } }]
    },
    select: { id: true, name: true, level: true }
  });

  console.log(`Groups with trailing dashes: ${groups.length}`);
  groups.forEach(g => {
    console.log(`  ID ${g.id}: name="${g.name}" level="${g.level}"`);
  });

  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
