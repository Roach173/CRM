const { PrismaClient, AdjType, ManualEntryType } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  try {
    console.log('🌱 Seeding complete teacher salary data...\n');

    // Find the teacher
    let teacher = await prisma.user.findFirst({
      where: { role: 'TEACHER' },
      include: { school: true, staffProfile: true }
    });

    if (!teacher) {
      console.log('ERROR: No teacher found.');
      process.exit(1);
    }

    const schoolId = teacher.schoolId;
    let staffProfile = teacher.staffProfile;

    // Ensure staffProfile exists
    if (!staffProfile) {
      staffProfile = await prisma.staffProfile.create({
        data: {
          userId: teacher.id,
          salaryRate: 500,
          position: 'Teacher',
          hireDate: new Date('2026-01-01')
        }
      });
      console.log(`✓ Created StaffProfile`);
    }

    console.log(`✓ Teacher: ${teacher.firstName} ${teacher.lastName}`);
    console.log(`✓ School: ${teacher.school.name}`);
    console.log(`✓ Salary rate: ${Number(staffProfile.salaryRate)} сом/урок\n`);

    // Find or create a lesson block
    let block = await prisma.lessonBlock.findFirst({
      where: {
        schoolId,
        teacherId: staffProfile.id
      }
    });

    if (!block) {
      // Find or create cabinet
      let cabinet = await prisma.cabinet.findFirst({
        where: { schoolId }
      });

      if (!cabinet) {
        cabinet = await prisma.cabinet.create({
          data: {
            name: 'Кабинет 1',
            capacity: 15,
            schoolId
          }
        });
      }

      // Find or create group
      let group = await prisma.studentGroup.findFirst({
        where: { schoolId }
      });

      if (!group) {
        group = await prisma.studentGroup.create({
          data: {
            schoolId,
            name: 'Группа A',
            level: 'Intermediate',
            maxStudents: 15
          }
        });
      }

      block = await prisma.lessonBlock.create({
        data: {
          schoolId,
          studentGroupId: group.id,
          cabinetId: cabinet.id,
          teacherId: staffProfile.id,
          startTime: '09:00',
          endTime: '10:20',
          days: 'Пн,Ср,Пт',
          level: 'Intermediate',
          maxStudents: 15,
          type: 'GRAMMAR',
          status: 'UPCOMING',
          startDate: new Date('2026-01-01')
        }
      });
      console.log('✓ Создан LessonBlock\n');
    }

    // Create completed sessions for Feb, Mar, Apr
    console.log('📅 Создание сессий...}\n');

    const sessionsToCreate = [
      // February 2026
      { date: new Date(2026, 1, 2), month: '2026-02' },  // Mon
      { date: new Date(2026, 1, 4), month: '2026-02' },  // Wed
      { date: new Date(2026, 1, 6), month: '2026-02' },  // Fri
      { date: new Date(2026, 1, 9), month: '2026-02' },  // Mon
      { date: new Date(2026, 1, 11), month: '2026-02' }, // Wed
      { date: new Date(2026, 1, 13), month: '2026-02' }, // Fri
      { date: new Date(2026, 1, 16), month: '2026-02' }, // Mon
      { date: new Date(2026, 1, 18), month: '2026-02' }, // Wed
      { date: new Date(2026, 1, 20), month: '2026-02' }, // Fri
      { date: new Date(2026, 1, 23), month: '2026-02' }, // Mon
      { date: new Date(2026, 1, 25), month: '2026-02' }, // Wed
      { date: new Date(2026, 1, 27), month: '2026-02' }, // Fri
      // March 2026
      { date: new Date(2026, 2, 2), month: '2026-03' },  // Mon
      { date: new Date(2026, 2, 4), month: '2026-03' },  // Wed
      { date: new Date(2026, 2, 6), month: '2026-03' },  // Fri
      { date: new Date(2026, 2, 9), month: '2026-03' },  // Mon
      { date: new Date(2026, 2, 11), month: '2026-03' }, // Wed
      { date: new Date(2026, 2, 13), month: '2026-03' }, // Fri
      { date: new Date(2026, 2, 16), month: '2026-03' }, // Mon
      { date: new Date(2026, 2, 18), month: '2026-03' }, // Wed
      { date: new Date(2026, 2, 20), month: '2026-03' }, // Fri
      { date: new Date(2026, 2, 23), month: '2026-03' }, // Mon
      { date: new Date(2026, 2, 25), month: '2026-03' }, // Wed
      { date: new Date(2026, 2, 27), month: '2026-03' }, // Fri
      // April 2026 (just a few)
      { date: new Date(2026, 3, 1), month: '2026-04' },  // Wed
      { date: new Date(2026, 3, 3), month: '2026-04' },  // Fri
      { date: new Date(2026, 3, 6), month: '2026-04' },  // Mon
    ];

    let createdCount = 0;
    for (const { date, month } of sessionsToCreate) {
      const existing = await prisma.lessonSession.findFirst({
        where: {
          lessonBlockId: block.id,
          date: {
            gte: new Date(date.getTime() - 60000),
            lte: new Date(date.getTime() + 60000)
          }
        }
      });

      if (!existing) {
        date.setHours(9, 0, 0, 0);
        await prisma.lessonSession.create({
          data: {
            schoolId,
            lessonBlockId: block.id,
            date,
            status: 'COMPLETED'
          }
        });
        createdCount++;
      }
    }

    console.log(`  ✓ Создано ${createdCount} сессий\n`);

    // Ensure salary adjustments exist with createdById
    console.log('💰 Salary adjustments:\n');

    // Find an admin user
    let admin = await prisma.user.findFirst({
      where: {
        role: 'ADMIN',
        schoolId
      }
    });

    if (!admin) {
      admin = await prisma.user.findFirst({
        where: { role: 'OWNER', schoolId }
      });
    }

    const adminId = admin?.id || null;

    const adjustments = [
      {
        month: '2026-02',
        type: AdjType.FINE,
        amount: 500,
        reason: 'Опоздание на занятие',
        createdById: adminId
      },
      {
        month: '2026-03',
        type: AdjType.BONUS,
        amount: 2000,
        reason: 'Отличные отзывы студентов',
        createdById: adminId
      },
      {
        month: '2026-03',
        type: AdjType.ADVANCE,
        amount: 5000,
        reason: 'Аванс на апрель',
        createdById: adminId
      },
      {
        month: '2026-04',
        type: AdjType.BONUS,
        amount: 1500,
        reason: 'Безопасные посещения',
        createdById: adminId
      }
    ];

    for (const adj of adjustments) {
      const existing = await prisma.salaryAdjustment.findFirst({
        where: {
          staffProfileId: staffProfile.id,
          month: adj.month,
          reason: adj.reason
        }
      });

      if (!existing) {
        await prisma.salaryAdjustment.create({
          data: {
            schoolId,
            staffProfileId: staffProfile.id,
            ...adj,
            date: new Date(adj.month + '-15')
          }
        });
        console.log(`  ${adj.month} | ${adj.type} | ${adj.amount} сом | "${adj.reason}"`);
      }
    }

    console.log();

    // Ensure manual entries exist
    console.log('📝 Manual lesson entries:\n');

    const manualEntries = [
      {
        month: '2026-02',
        type: ManualEntryType.ADD,
        label: 'Замена за коллегу (группа B)',
        count: 2,
        createdById: adminId
      },
      {
        month: '2026-02',
        type: ManualEntryType.REMOVE,
        label: 'Болезнь (2 дня)',
        count: 2,
        createdById: adminId
      },
      {
        month: '2026-03',
        type: ManualEntryType.ADD,
        label: 'Дополнительный семинар',
        count: 1,
        createdById: adminId
      },
      {
        month: '2026-04',
        type: ManualEntryType.ADD,
        label: 'Замена выходного дня',
        count: 1,
        createdById: adminId
      }
    ];

    for (const entry of manualEntries) {
      const existing = await prisma.manualLessonEntry.findFirst({
        where: {
          staffProfileId: staffProfile.id,
          month: entry.month,
          label: entry.label
        }
      });

      if (!existing) {
        await prisma.manualLessonEntry.create({
          data: {
            schoolId,
            staffProfileId: staffProfile.id,
            ...entry
          }
        });
        console.log(`  ${entry.month} | ${entry.type === 'ADD' ? '+' : '−'}${entry.count} | "${entry.label}"`);
      }
    }

    console.log();

    // Create or update payment records
    console.log('📋 Payment records:\n');

    for (const period of ['2026-02', '2026-03']) {
      const existing = await prisma.teacherPayment.findFirst({
        where: {
          staffProfileId: staffProfile.id,
          period
        }
      });

      if (!existing) {
        // Count sessions
        const [year, month] = period.split('-').map(Number);
        const startDate = new Date(year, month - 1, 1);
        const endDate = new Date(year, month, 0, 23, 59, 59);

        const sessionCount = await prisma.lessonSession.count({
          where: {
            lessonBlockId: block.id,
            status: 'COMPLETED',
            date: { gte: startDate, lte: endDate }
          }
        });

        // Count manual delta
        const manualDelta = manualEntries
          .filter(e => e.month === period)
          .reduce((sum, e) => sum + (e.type === 'ADD' ? e.count : -e.count), 0);

        const effectiveLessons = Math.max(0, sessionCount + manualDelta);
        const rate = Number(staffProfile.salaryRate);
        const gross = effectiveLessons * rate;

        const monthAdj = adjustments.filter(a => a.month === period);
        const bonuses = monthAdj
          .filter(a => a.type === AdjType.BONUS)
          .reduce((s, a) => s + a.amount, 0);
        const fines = monthAdj
          .filter(a => a.type === AdjType.FINE)
          .reduce((s, a) => s + a.amount, 0);
        const advances = monthAdj
          .filter(a => a.type === AdjType.ADVANCE)
          .reduce((s, a) => s + a.amount, 0);
        const net = gross + bonuses - fines - advances;

        await prisma.teacherPayment.create({
          data: {
            schoolId,
            staffProfileId: staffProfile.id,
            period,
            lessonsCount: effectiveLessons,
            rateSnapshot: rate,
            amount: net,
            note: `Выплата за ${period}`,
            paidAt: new Date(period + '-30'),
            createdById: adminId
          }
        });

        console.log(`  ${period}`);
        console.log(`    Sessions: ${sessionCount} × ${rate} сом = ${gross} сом`);
        if (manualDelta !== 0) console.log(`    Manual delta: ${manualDelta > 0 ? '+' : ''}${manualDelta}`);
        if (bonuses) console.log(`    + Bonuses: ${bonuses} сом`);
        if (fines) console.log(`    − Fines: ${fines} сом`);
        if (advances) console.log(`    − Advances: ${advances} сом`);
        console.log(`    = Net: ${net} сом\n`);
      }
    }

    console.log('✅ Seed complete!\n');
    console.log(`📊 Summary:`);
    console.log(`  • Teacher: ${teacher.firstName} ${teacher.lastName}`);
    console.log(`  • School: ${teacher.school.name}`);
    console.log(`  • Salary rate: ${Number(staffProfile.salaryRate)} сом/урок`);
    console.log(`  • Lesson sessions: Feb-Apr`);
    console.log(`  • Salary adjustments: ${adjustments.length}`);
    console.log(`  • Manual lesson entries: ${manualEntries.length}`);
    console.log(`\n🔗 Login as teacher at:`);
    console.log(`  http://localhost:5173/my-school/login`);
    console.log(`  Email: teacher@example.com`);
    console.log(`  Password: teacher123\n`);
    console.log(`👤 Go to your profile → "Зарплата" tab to see:\n`);
    console.log(`  ✓ Monthly selector (Feb, Mar, Apr...)`);
    console.log(`  ✓ Your salary rate`);
    console.log(`  ✓ Auto-calculated lessons from schedule`);
    console.log(`  ✓ Manual entries (добавлено админом, но БЕЗ имени админа)`);
    console.log(`  ✓ Штрафы, авансы, бонусы (ТОЛЬКО СУММА, без деталей)`);
    console.log(`  ✓ Net salary total`);
    console.log(`  ✓ Payment status\n`);

  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();
