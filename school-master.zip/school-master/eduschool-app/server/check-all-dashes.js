const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('Checking LessonBlock...\n');

  const blocks = await prisma.lessonBlock.findMany({
    where: { deletedAt: null },
    select: { id: true, startTime: true, endTime: true, level: true },
    take: 20
  });

  console.log('Sample LessonBlocks:');
  blocks.forEach(b => {
    const hasStartDash = b.startTime.includes('-');
    const hasEndDash = b.endTime.includes('-');
    const hasLevelDash = b.level.includes('-');
    console.log(`  ID ${b.id}: "${b.startTime}" (dash:${hasStartDash}) | "${b.endTime}" (dash:${hasEndDash}) | "${b.level}" (dash:${hasLevelDash})`);
  });

  console.log('\n\nChecking StudentGroup...\n');

  const groups = await prisma.studentGroup.findMany({
    where: { deletedAt: null },
    select: { id: true, name: true, level: true },
    take: 20
  });

  console.log('Sample StudentGroups:');
  groups.forEach(g => {
    const hasLevelDash = g.level.includes('-');
    console.log(`  ID ${g.id}: name="${g.name}" level="${g.level}" (dash:${hasLevelDash})`);
  });

  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
