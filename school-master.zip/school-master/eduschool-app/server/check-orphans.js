const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function check() {
  try {
    const orphanBlocks = await prisma.$queryRaw`
      SELECT lb.id, lb."teacherId", lb."startTime", lb."cabinetId"
      FROM "LessonBlock" lb
      WHERE lb."teacherId" IS NOT NULL
      AND lb."teacherId" NOT IN (SELECT id FROM "StaffProfile" WHERE "deletedAt" IS NULL)
    `;
    console.log('Orphan LessonBlocks:');
    console.log(JSON.stringify(orphanBlocks, null, 2));
    console.log(`Total: ${orphanBlocks.length}`);

    const orphanSessions = await prisma.$queryRaw`
      SELECT ls.id, ls."teacherId", ls."date"
      FROM "LessonSession" ls
      WHERE ls."teacherId" IS NOT NULL
      AND ls."teacherId" NOT IN (SELECT id FROM "StaffProfile" WHERE "deletedAt" IS NULL)
    `;
    console.log('\nOrphan LessonSessions:');
    console.log(JSON.stringify(orphanSessions, null, 2));
    console.log(`Total: ${orphanSessions.length}`);
  } catch (err) {
    console.error('Error:', err);
  } finally {
    await prisma.$disconnect();
  }
}

check();
