# Full Correctness, Security & Performance Audit — Brief (2026-08-08)

**Read this file fully before doing anything else.** `CLAUDE.md` at the repo root is auto-loaded and governs workflow/process — this file governs *scope and standard* for this specific audit. Branch: `feature/full-app-check-2` (already created off `dev`, currently identical to `master`).

## 0. Why this exists

Over roughly 2 hours on 2026-08-08, a prior session migrated hosting (Render+Vercel+Supabase → Railway, all-in-one project: API + Postgres + client) and, purely by clicking around the live app afterward, found and fixed six real bugs one at a time: `prisma-erd-generator` crashing the production build (headless Chrome missing in the Nixpacks image — fixed via `DISABLE_ERD=true`), a wrong `dist/` entry path (`dist/index.js` vs the real `dist/src/index.js`, from `tsconfig.json`'s `rootDir`), two stray compiled config files (`vite.config.js`, `tailwind.config.js`) accidentally committed to git and shadowing their `.ts` sources, Vite preview's `allowedHosts` blocking the Railway domain, a service worker doing a naive `event.respondWith(fetch(event.request))` passthrough that added real per-request latency (300-700ms+) plus service-worker cold-start delays, and missing CORS `Access-Control-Max-Age` (no preflight caching between the now cross-origin client/API).

Every one of these was found reactively — never via a systematic sweep. The owner is explicitly done with that pattern and wants this audit to be the opposite: exhaustive, evidence-based, enterprise-QA-caliber. Not a rubber-stamped checklist.

**Honest framing, stated up front so expectations are calibrated correctly**: "zero bugs, nothing anyone could ever find fault with" is not an achievable bar for any real software — not for this app, not for Google's. What *is* achievable, and is the actual target here, is a level of scrutiny that would hold up against a serious external security/QA review: every claim backed by evidence (a file:line, a test result, a reproduced failure), not by "looks fine." If a section below turns out clean, say so with the evidence that makes it clean — don't skip it silently.

**On scope and pacing**: this brief is intentionally large — comparable to what a dedicated QA/security team would spend real time on. Depending on how much is actually broken versus already-fine, closing all of it properly (with tests, not just patches) may not fit in one PR. That's fine and expected — `CLAUDE.md`'s own Golden Rule (one task = one branch = one PR = one chat) still applies **within** this effort: if a section surfaces a large independent piece of work, split it into its own properly-scoped PR off `dev` rather than cramming everything into one unreviewable diff. Use judgment; note the split explicitly in your final report so the owner can track it.

## 1. What NOT to redo

`PRODUCTION_READINESS.md` (repo root of `eduschool-app/`) is a completed prior audit — read it fully first. Phases 1-7 and 9 are checked off and were verified with actual browser testing: CI safety net, security hardening (rate limiting, CSRF, weak-password fixes, xlsx CVE), zod validation on the weakest input-validation spots, structured logging + all env vars documented, frontend component-test capability, doc sync, PWA/bundle polish, and a full OWASP Top-10 pass. Don't re-litigate these from scratch — spot-check at most, and only where this session's Railway migration plausibly touches them (CORS/cookies/origins changed; the rest didn't).

The one item that document explicitly left open: **Phase 9, A05** — roughly 20 route files forward raw `err.message` verbatim in their generic 500 fallback (not the controlled business-logic error paths). No file list was given. Find them, decide case-by-case whether the message is safe to expose or needs genericizing, fix all of them.

The document also explicitly states hosting/infra was *out of scope* for that audit. That means this entire Railway migration, and everything found during it, has never been systematically reviewed — that's real, unclaimed ground for this audit (see §9).

## 2. Process — build the checklist from the filesystem, not from memory

Don't work from a mental model of "the important pages." Enumerate for real:

```
ls server/src/routes/          # 39 route files total (29 here + 10 under schedule/)
ls server/src/routes/schedule/
ls -R client/src/pages/        # 48 page files across admin/owner/parent/student/superadmin/teacher/communications/settings
```

Turn each into an actual checklist (a markdown table is fine) and work through every row. "I reviewed the schedule domain" is not evidence; "reviewed `scheduleAttendance.ts`, `scheduleBlocks.ts`, ... — findings: X, Y; clean: confirmed schoolId-scoped on all 12 queries, see lines N/M/..." is evidence.

## 3. Multi-tenancy & authorization — systematic, not spot-check

For every one of the 39 route files: confirm every DB query filters by `req.user.schoolId` (per `CLAUDE.md`: "No exceptions"). Build an explicit table: route file → endpoint → schoolId-scoped (Y/N) → role check present and correct against the OWNER/ADMIN/TEACHER/STUDENT/SUPERADMIN matrix in `CLAUDE.md`.

Then don't just read the code — **try to break it live**: as a TEACHER or STUDENT test account, attempt to fetch/modify a resource ID belonging to a different school or a different user (IDOR) on a handful of the highest-value endpoints (credits, attendance, salary, student profiles). Report what you tried and what happened, not just what the code appears to do.

## 4. Financial & data integrity

Every credit deduction, salary payment, and `SalaryAdjustment` — confirm it's wrapped in a Prisma transaction (not just "usually is"). Confirm idempotency flags (`Attendance.creditDeducted`, etc.) are actually enforced at every call site that could double-fire, not just present in the schema. Specifically test (not just reason about): what happens on a double-submit of the same attendance/payment action in quick succession — does it double-deduct? Race it if you can.

Re-verify the Schedule Rules cancel guard from `CLAUDE.md`: sessions with `creditDeducted = true` cannot be normally cancelled, and cancellation never auto-refunds credit. Confirm this holds at every code path that can cancel/delete a session, not just the obvious one.

## 5. Business logic per domain

Cross-check actual code behavior against `AI_SCHEDULE_HANDOFF.md` and `SCHEDULE_LIFECYCLE_RFC.md` for: session lifecycle, `StudentFreeze` (source of truth — `StudentProfile.isFrozen`/`frozenAt` are legacy cache only, per `CLAUDE.md`), waitlist/`EnrollmentRequest`, salary calculation. Specifically exercise the edge cases `CLAUDE.md`'s Business Logic Rule requires answers for: lesson cancelled after credit already deducted, salary already paid, deadline passed, stale/conflicting concurrent edits, legacy-data shapes (e.g., `enrolledBlocks` vs `StudentGroup`).

## 6. Security — delta since the migration, plus fresh eyes

- CORS/cookie correctness for the new cross-origin Railway topology: `SameSite`, `credentials`, the `ALLOWED_ORIGINS` value actually matches the live client domain (a typo here fails silently, as already flagged this session).
- Grep logs and code for anything that could leak a secret (API keys, tokens) into logs or client-visible responses.
- Rate limits still appropriate at real traffic patterns on Railway.
- The A05 backlog item (§1) — fix it.
- A fresh IDOR/mass-assignment pass beyond what Phase 9's OWASP sweep already covered — look specifically at any endpoint added or touched since 2026-08-02 (Phase 9's date).

## 7. Performance

Look for siblings of the service-worker bug — anything else doing a redundant round trip, missing memoization on expensive client computations, N+1 Prisma queries on hot paths (`include`/`select` review), or a query pattern added since the composite indexes were designed that isn't covered by them. Manually time the heaviest pages (Schedule, Analytics/heatmap) — not just on the empty pilot DB, reason about behavior at the documented 50k-student target too, referencing the existing composite indexes (`LessonSession(schoolId,date)`, etc. — see `CLAUDE.md`) to check the query patterns you find actually use them (`EXPLAIN`, don't guess).

## 8. Frontend correctness & UX — manual walkthrough (this is how every bug this session was actually found)

Log in as each of the five roles and click through every one of the 48 pages relevant to that role: loading states, empty states (this app is on a fresh pilot DB — empty states are exercised *by default* right now, use that), error states (kill the network mid-request, see what happens), form validation messages, mobile viewport. Confirm the No Drag & Drop and No Autosave policies (`CLAUDE.md`) are actually enforced everywhere — not bypassed on some page that predates the policy.

## 9. Config/infra — the actual gap this migration exposed

Build a table from `server/.env.example`: variable → required in prod? → confirmed set to a real value on Railway (not a dummy fallback) → confirmed actually working (not just "set"). The pattern to hunt for is already proven live twice: `GOOGLE_CLIENT_ID` (client falls back to `dummy-client-id.apps.googleusercontent.com`, confirmed 403 on `Login.tsx`, and the **same unfixed bug exists at `client/src/pages/RegisterSchool.tsx:376`** — fix both together) and `RESEND_API_KEY` (`server/src/lib/email.ts:5` falls back to `re_dummy`, fails silently). Find any other silent-dummy-fallback landmine in the same shape.

Concrete unfinished items from this session, close these out:
- `RegisterSchool.tsx:376` — same Google client-id fallback as `Login.tsx`.
- Confirm `DISABLE_ERD=true` is actually set as a Railway env var (it's in CI's `pr-checks.yml`, that does **not** confirm it's set on the live Railway service — check the dashboard, not just the repo).
- Postgres backup verification on Railway (Pro plan, daily backups) — confirm actually enabled, then perform one real test-restore. This was agreed early in the migration session and never actually done.
- `render.yaml` and `vercel.json` are now dead config (migrated off Render/Vercel to Railway) — remove them, and update anything in `DEPLOYMENT.md`/`AI_SCHEDULE_HANDOFF.md` that still assumes the old topology.

## 10. Tests

Actually run the full suite — 100 server test files (24 unit, 76 integration against a real Postgres) and 17 client test files — don't assume green. Fix any failures. Then identify critical paths with no coverage, especially anything touched or found broken this session (service worker behavior, CORS, the dist entry path), and add tests for them.

## 11. Accessibility (baseline pass)

Keyboard navigation through primary flows (login, schedule, attendance marking), form labels present, sufficient color contrast on key UI (the theme's `primary: #2D6A4F` against white — check text-on-color contrast ratios). Not a full WCAG audit — a baseline sanity pass.

## 12. Documentation sync

Per `CLAUDE.md`'s own Documentation Update Rule: as you fix things, update the relevant doc (scheduling → `AI_SCHEDULE_HANDOFF.md` changelog; API changes → `API_CONTRACTS.md`; DB changes → `DATABASE_CONSTRAINTS.md`). When this audit is substantially done, add a **Phase 10** entry to `PRODUCTION_READINESS.md` summarizing what was found and fixed, in the same format as the existing phases — so the next person (human or AI) has one place that reflects reality, the way this audit's own §1 relied on Phase 9 existing.

## 13. Report format

For each section above: what was checked, what was found (with file:line and a concrete failure scenario — "X breaks when Y" — not just a category label), what was fixed, what's left open and why (genuinely can't fix now / needs owner decision / needs its own separate PR). Findings without a reproducible failure scenario go in a "needs verification" bucket, not the fixed list.
