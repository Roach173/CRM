-- Ensure postgres user has password auth enabled
ALTER USER postgres WITH ENCRYPTED PASSWORD 'admin';

-- Initialize schema with migrations applied
-- (Migrations will be applied via Prisma on first app startup)
CREATE SCHEMA IF NOT EXISTS public;
