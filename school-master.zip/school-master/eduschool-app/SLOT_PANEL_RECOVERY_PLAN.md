# SlotPanel Recovery Plan

Date: 2026-05-23

## Problem

After `SlotPanel.tsx` was split into `SlotPanel`, `GroupRow`, `EditGroupPanel`, and `EditSessionPanel`, the schedule UI repeatedly gets stuck in `Saving...` during:

- edit group
- edit lesson
- submit attendance

The visible symptom is not the root issue. The root issue is that the UI now coordinates several related schedule mutations from separate components, while the backend still exposes mostly block-level endpoints.

## What Git History Shows

Old monolithic `SlotPanel.tsx` versions checked:

- `5969476e` - full SlotPanel restore
- `47e1cacc` - smart conflict detection restore
- `935f9cf2` - temporal ERP architecture
- `ddfbdaa3` - split into components

Old flow inside the monolith:

1. `EditGroupPanel.save()`
2. `PUT /groups/:id` once, if group metadata changed
3. `PUT /schedule/:grammarBlockId`
4. `PUT /schedule/:clubBlockId` or `POST /schedule` for club
5. `onDone()`
6. `onReload()`

Current split flow is still basically this sequence, but the system now has stricter invariants:

- temporal block splitting with `applyFrom`
- `GRAMMAR_CLUB_DAY_CONFLICT`
- live conflict engine
- real `grammarBlockId` and `clubBlockId`
- session snapshots and attendance billing

That means two separate `PUT /schedule/:id` calls are no longer safe as the core save protocol for a Grammar+Club pair.

## Root Cause Hypothesis

The UI saves one logical group schedule as multiple independent HTTP requests.

For a group with Grammar + Speaking Club, the intended final state is a pair:

- Grammar days, teacher, cabinet, slot
- Club days, teacher, cabinet, slot
- shared `studentGroupId`
- shared temporal decision: in-place update or split from date

But the backend validates each block independently against the database state that still contains the other block in its old form. During save, the system can temporarily see an invalid half-updated pair.

This explains why fixing local component props or block ids does not fully solve the problem. The save protocol itself is wrong for the current backend rules.

## Immediate Stabilization

Before the deeper fix, add diagnostics and fail-fast behavior:

1. Add request timeouts to attendance submission and all schedule mutations.
2. Log the exact step in `EditGroupPanel`:
   - group metadata save
   - grammar block save
   - club block save
   - reload
3. Show a real error if a request times out instead of leaving `Saving...`.
4. Disable submit attendance while group edit save is active for the same row.
5. Add a debug payload in failed toasts during development:
   - endpoint
   - block id
   - date
   - server error code

This does not fix the architecture, but it prevents invisible hangs.

## Proper Fix

Create a backend endpoint for saving the whole Grammar+Club pair atomically.

Suggested endpoint:

`PUT /api/v1/schedule/group-pair/:studentGroupId`

Request shape:

```ts
{
  grammarBlockId?: number;
  clubBlockId?: number;
  timeSlotId: number;
  cabinetId: number;
  level: string;
  chapter: number;
  maxStudents: number;
  grammarTeacherId: number | null;
  grammarDays: number[];
  clubTeacherId: number | null;
  clubDays: number[];
  applyFrom?: string;
  overrideCabinetConflict?: boolean;
  overrideTeacherConflict?: boolean;
  overrideStudentConflict?: boolean;
}
```

Backend behavior:

1. Load the `StudentGroup` and both active blocks under `schoolId`.
2. Reject Grammar/Club day overlap before DB mutation.
3. Validate the final pair against all other groups, excluding both current pair block ids.
4. If `applyFrom` is present:
   - close both old blocks at `applyFrom - 1 day`
   - create new Grammar and Club block versions in one transaction
5. If `applyFrom` is absent:
   - update both blocks in one transaction
6. Update `StudentGroup` metadata once.
7. After transaction:
   - `cleanupInvalidSessions()` for changed old blocks
   - `syncSessionsForBlock()` for new/current blocks
   - invalidate schedule cache
8. Return both updated block ids and mapped block data.

This removes the transient invalid state caused by two client-side `PUT` calls.

## Frontend Refactor

`EditGroupPanel` should stop calling:

- `PUT /groups/:id`
- `PUT /schedule/:grammarBlockId`
- `PUT /schedule/:clubBlockId`
- `POST /schedule` for club

Instead it should call one pair endpoint.

`EditGroupPanel` remains responsible only for:

- form state
- client-side preview conflicts
- choosing apply mode: `applyFrom` or all lessons
- rendering errors

It should not orchestrate multi-step schedule writes.

## Attendance Fixes

Attendance should be treated separately from group editing.

Required changes:

1. Resolve lesson block id only through `lessonBlockIdForDay(group, ci)`.
2. Before submit, call or reuse `session/for-date` result.
3. Add timeout to `POST /session/submit-attendance`.
4. If the lesson block no longer matches the selected date after a group save, force reload first and disable submit until reload completes.
5. Replace local submitted state as the primary signal with server attendance/session status.

## Regression Tests

Add tests for these scenarios:

1. Save group where Grammar loses a day and Club gains that day.
2. Save group where Club loses a day and Grammar gains that day.
3. Save from current date using `applyFrom`.
4. Save to all lessons without split.
5. Submit attendance after group edit reload.
6. Edit lesson replacement teacher and then submit attendance.
7. Rooms view uses real Grammar/Club block ids for cancelled/substitute state.

## Manual Verification Script

Use this exact scenario:

1. Open schedule week.
2. Open a slot with one group that has Grammar + Club.
3. Open `Edit group`.
4. Move one day from Grammar to Club.
5. Save from current date.
6. Confirm modal closes and group row reloads.
7. Open the same row.
8. Mark one student present.
9. Submit attendance.
10. Reload page.
11. Verify:
    - days are still correct
    - no endless `Saving...`
    - attendance remains saved
    - salary/session status sees the correct teacher

## Decision

Do not keep patching `GroupRow` and `EditGroupPanel` around the current multi-request save flow. The root fix is to move Grammar+Club pair save into a single backend command and make the frontend call that one command.

## Implemented 2026-05-23

- Added `PUT /api/v1/schedule/group-pair/:studentGroupId` in `server/src/routes/schedule.ts`.
- `EditGroupPanel` now calls the pair endpoint once instead of calling `PUT /groups/:id`, `PUT /schedule/:grammarBlockId`, `PUT /schedule/:clubBlockId`, and optional `POST /schedule`.
- `scheduleValidation.validateScheduleBlock()` now accepts `excludeBlockIds`, so pair validation can ignore both current Grammar and Club block ids while validating the final state.
- The pair endpoint validates Grammar/Club day overlap before mutation, validates both final blocks inside one transaction, updates `StudentGroup` metadata once, splits both blocks together when `applyFrom` is present, syncs sessions after commit, and invalidates the schedule cache.
- Attendance submit now uses `lessonBlockIdForDay(group, ci)`, has a 30s request timeout, and ignores duplicate clicks while the request is in flight.

## StrictMode Root Cause Found 2026-05-23

The remaining endless `Saving...` was caused by the split components' `mountedRef` pattern in React StrictMode:

```ts
const mountedRef = useRef(true);
useEffect(() => () => { mountedRef.current = false; }, []);
```

In development, StrictMode intentionally runs mount -> cleanup -> mount. The cleanup set `mountedRef.current = false`, but the effect body never restored it to `true`. After that, async handlers skipped both success/error UI updates and `setSaving(false)`.

Required pattern:

```ts
const mountedRef = useRef(true);
useEffect(() => {
  mountedRef.current = true;
  return () => { mountedRef.current = false; };
}, []);
```

Fixed in:

- `CreateGroupForm.tsx`
- `EditGroupPanel.tsx`
- `EditSessionPanel.tsx`
- `GroupRow.tsx`

Regression coverage:

- `client/tests/mountedRefStrictMode.test.ts`
- `server/src/__tests__/integration/groupPairValidation.test.ts`

## Remaining Manual Check

Run the manual verification script above in the browser against real data. Automated build/type checks pass, but this workflow should still be clicked through because the original bug was visible only after interacting with the expanded slot panel.
